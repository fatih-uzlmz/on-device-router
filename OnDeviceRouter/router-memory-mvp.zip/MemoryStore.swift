import Foundation

/// One saved conversation turn.
struct MemoryExchange: Identifiable, Codable {
    let id: UUID
    let userMessage: String
    let assistantMessage: String
    /// "local" or "cloud" — useful context for later analysis.
    let route: String
    let timestamp: Date

    init(userMessage: String, assistantMessage: String, route: String) {
        self.id = UUID()
        self.userMessage = userMessage
        self.assistantMessage = assistantMessage
        self.route = route
        self.timestamp = Date()
    }
}

/// The app's memory interface. Everything the app needs from memory lives here,
/// so the implementation can be swapped later (e.g. memlocal) without touching
/// any calling code.
protocol MemoryStore {
    /// Save a finished turn.
    func save(_ exchange: MemoryExchange) async
    /// Best-matching past turns for a query, most relevant first.
    func recall(matching query: String, limit: Int) async -> [MemoryExchange]
    /// Ready-to-paste prompt section. Empty string when nothing relevant.
    func promptContext(matching query: String, limit: Int) async -> String
    /// How many turns are stored.
    func count() async -> Int
    /// Wipe everything.
    func clear() async
}
