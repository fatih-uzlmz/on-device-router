import Foundation

/// MVP memory: keeps recent turns on-device and recalls by keyword matching.
/// Zero dependencies, no embeddings, no network — everything stays on the phone.
///
/// Wiring (in RoutingEngine):
///   1. Add a property:  private let memory: any MemoryStore = SimpleMemoryStore()
///   2. In answer(_:), before routing:
///        let context = await memory.promptContext(matching: query)
///        let prompt = context.isEmpty ? query : context + "\n\nUser: " + query
///      Route the RAW query (memory text must never sway routing or trip the
///      privacy gate), but send `prompt` to the model. The audit entry still
///      hashes the raw query.
///   3. After getting `text`, save the turn — unless the privacy gate fired:
///        await memory.save(MemoryExchange(userMessage: query,
///                                         assistantMessage: text,
///                                         route: decision.destination.rawValue))
///
/// Tip: skip step 3 when the privacy gate forced the route, so sensitive text
/// never lands in the store at all.
///
/// Later: a MemlocalMemoryStore can adopt the same `MemoryStore` protocol and
/// replace this class with a one-line change in step 1. Nothing else moves.
@available(iOS 26.0, *)
actor SimpleMemoryStore: MemoryStore {

    /// How many turns to keep. Oldest are dropped first.
    private let capacity = 200
    private let fileName = "memories.json"

    private var exchanges: [MemoryExchange] = []

    init() {
        self.exchanges = Self.load(from: Self.storeURL(fileName: fileName))
    }

    // MARK: - MemoryStore

    func save(_ exchange: MemoryExchange) async {
        exchanges.append(exchange)
        if exchanges.count > capacity {
            exchanges.removeFirst(exchanges.count - capacity)
        }
        persist()
    }

    func recall(matching query: String, limit: Int = 3) async -> [MemoryExchange] {
        let words = Self.keywords(in: query)
        guard !words.isEmpty else { return [] }
        return exchanges
            .map { ($0, score($0, words: words)) }
            .filter { $0.1 > 0 }
            .sorted {
                if $0.1 != $1.1 { return $0.1 > $1.1 }      // more word hits first
                return $0.0.timestamp > $1.0.timestamp       // then most recent
            }
            .prefix(limit)
            .map { $0.0 }
    }

    func promptContext(matching query: String, limit: Int = 3) async -> String {
        let hits = await recall(matching: query, limit: limit)
        guard !hits.isEmpty else { return "" }
        let lines = hits.map { "- User: \($0.userMessage)\n  Assistant: \($0.assistantMessage)" }
        return "Relevant memories from earlier conversations:\n"
            + lines.joined(separator: "\n")
    }

    func count() async -> Int { exchanges.count }

    func clear() async {
        exchanges = []
        persist()
    }

    // MARK: - Keyword matching

    /// Lowercased words worth matching on (drops short filler like "is", "a").
    private static func keywords(in text: String) -> [String] {
        let words = text.lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { $0.count >= 3 }
        return Array(Set(words))
    }

    /// How many distinct query words appear in the exchange.
    private func score(_ exchange: MemoryExchange, words: [String]) -> Int {
        let haystack = (exchange.userMessage + " " + exchange.assistantMessage).lowercased()
        return words.reduce(0) { $0 + (haystack.contains($1) ? 1 : 0) }
    }

    // MARK: - Persistence (plain JSON in Application Support)

    private static func storeURL(fileName: String) -> URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory,
                                           in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir,
                                                 withIntermediateDirectories: true)
        return dir.appendingPathComponent(fileName)
    }

    private static func load(from url: URL) -> [MemoryExchange] {
        guard let data = try? Data(contentsOf: url) else { return [] }
        return (try? JSONDecoder().decode([MemoryExchange].self, from: data)) ?? []
    }

    private func persist() {
        let url = Self.storeURL(fileName: fileName)
        guard let data = try? JSONEncoder().encode(exchanges) else { return }
        try? data.write(to: url, options: .atomic)
    }
}
